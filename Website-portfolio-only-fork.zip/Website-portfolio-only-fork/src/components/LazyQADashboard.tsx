"use client";

import React from 'react';
import { QADashboard } from '@/components/ui/QADashboard';

export function LazyQADashboard() {
  return <QADashboard />;
}