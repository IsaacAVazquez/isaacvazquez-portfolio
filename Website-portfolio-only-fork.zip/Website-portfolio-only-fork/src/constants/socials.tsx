import { IconBrandLinkedin } from "@tabler/icons-react";

export const socials = [
  {
    href: "https://www.linkedin.com/in/isaac-vazquez/",
    label: "LinkedIn",
    icon: IconBrandLinkedin,
  },
];
